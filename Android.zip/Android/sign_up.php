<?php

	define('host', 'localhost');
	define('user', 'root');
	define('pass', '');
	define('db', 'products');

	$conn = mysqli_connect(host, user, pass, db) or die('Unable to Connect');

    if($_SERVER['REQUEST_METHOD'] == 'POST') {
        
    $fname = mysqli_real_escape_string($conn, $_POST['fname']);
    $lname = mysqli_real_escape_string($conn,$_POST['lname']);
    $email= mysqli_real_escape_string($conn,$_POST['email']);
    $id_number= mysqli_real_escape_string($conn, $_POST['id_number']);
    $phone = mysqli_real_escape_string($conn,$_POST['phone']);
    $password = mysqli_real_escape_string($conn,$_POST['password']);

    $check_query = "SELECT * FROM users WHERE email='$email' ";
    $check_result_query =mysqli_fetch_array(mysqli_query($conn,$check_query));

    if (isset($check_result_query)) {
        // User already exists
        $result["success"] = "0";
        $result["message"] = "Đăng ký thất bại, tài khoản đã tồn tại";

            echo json_encode($result);
            echo $result[message];
    }

    else{

        // Create user
        $sql=mysqli_query($conn, 'INSERT INTO users(email,password,fname,lname,id_number,phone)
            VALUES("'.$_POST['email'].'","'.$_POST['password'].'","'.$_POST['fname'].'","'.$_POST['lname'].'","'.$_POST['id_number'].'","'.$_POST['phone'].'")');


            if (!$sql) {
            die (mysqli_error($conn));
            }

    else {

            $result["success"] = "1";
            $result["message"] = "Đăng ký thành công !";

            echo json_encode($result);
            echo $result;
    }

    }}

    else {

            $result["success"] = "0";
            $result["message"] = "ERROR !!!";

            echo json_encode($result);
            echo $result;
    }


?>
