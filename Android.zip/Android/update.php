<?php

    define('host', 'localhost');
    define('user', 'root');
    define('pass', '');
    define('db', 'products');

    $conn = mysqli_connect(host, user, pass, db) or die('Unable to Connect');

    $title  = $_POST['title'];
    $price  = $_POST['price'];
    $rating = $_POST['rating'];
    $image  = $_POST['image'];
    $oldtitle = $_POST['oldtitle'];

    $sql = "SELECT * FROM shop WHERE title = '$title'";
    $check = mysqli_query($conn,$sql);

    if (mysqli_num_rows($check) > 0){
        $result = "UPDATE shop 
        SET title = '$title', price = '$price', rating = '$rating', image = '$image' WHERE title = '$oldtitle'";
        if (mysqli_query($conn,$result)) 
        {
            echo"Sửa thành công !";
        }
        else
        {
            echo"Thất bại.";
        }

    }
    else
    {
        echo"Không tồn tại.";
    }


?>
