<?php 
    define('host', 'localhost');
    define('user', 'root');
    define('pass', '');
    define('db', 'products');

    $conn = mysqli_connect(host, user, pass, db) or die('Unable to Connect');
    header("Content-Type: application/json; charset=UTF-8");



    $query = "SELECT * FROM shop ORDER BY id DESC ";
    $result = mysqli_query($conn, $query);
    $response = array();

    $server_name = $_SERVER['SERVER_ADDR'];

    while( $row = mysqli_fetch_assoc($result) ){

        array_push($response, 
        array(
            'id'      =>$row['id'], 
            'title'   =>$row['title'], 
            'price'   =>$row['price'],
            'rating'  =>$row['rating'],
            'image'   =>$row['image'])

        );
        
    }

    echo json_encode($response);

    mysqli_close($conn);

?>