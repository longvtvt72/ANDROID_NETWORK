<?php
	define('host', 'localhost');
	define('user', 'root');
	define('pass', '');
	define('db', 'products');

	$conn = mysqli_connect(host, user, pass, db) or die('Unable to Connect');

	if($_SERVER['REQUEST_METHOD'] == 'POST')
	{
		$email=$_POST['email'];
		$password=$_POST['password'];

		$que=mysqli_query($conn,"SELECT * FROM users WHERE email ='$email' AND password='$password'");
		$row=mysqli_num_rows($que);

		if($row)
		{
	        $result["success"] = "1";
		    $result["message"] = "Đăng nhập thành công.";
			echo json_encode($result);
	    }

		else{
			$result["success"] = "0";
			$result["message"] = "Sai tên tài khoản hoặc mật khẩu !";
			echo json_encode($result);
		}
	}
?>
