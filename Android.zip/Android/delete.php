<?php

    define('host', 'localhost');
    define('user', 'root');
    define('pass', '');
    define('db', 'products');

    $conn = mysqli_connect(host, user, pass, db) or die('Unable to Connect');

    $title = $_POST["title"];
    $query = "SELECT * FROM shop WHERE title='$title'";
    $check = mysqli_query($conn,$query);
    $result = array();
    

    if (mysqli_num_rows($check) === 1)
    {
        $sql = "DELETE FROM shop WHERE title='$title'";
        if (mysqli_query($conn,$sql)) {
            $result['state'] = "delete";
            echo json_encode($result);
        }else{
            echo "Xóa thành công";
        }
        
    }
    else
    {
        echo "Xóa thất bại";
    }
    mysqli_close($conn);
?>