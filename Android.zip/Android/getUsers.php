<?php 
    define('host', 'localhost');
    define('user', 'root');
    define('pass', '');
    define('db', 'products');

    $conn = mysqli_connect(host, user, pass, db) or die('Unable to Connect');
    header("Content-Type: application/json; charset=UTF-8");



    $query = "SELECT * FROM users ORDER BY id DESC ";
    $result = mysqli_query($conn, $query);
    $response = array();

    $server_name = $_SERVER['SERVER_ADDR'];

    while( $row = mysqli_fetch_assoc($result) ){

        array_push($response, 
        array(
            'id'        =>$row['id'], 
            'fname'     =>$row['fname'], 
            'lname'     =>$row['lname'],
            'email'     =>$row['email'],
            'id_number' =>$row['id_number'],
            'phone'     =>$row['phone'])
        );
        
    }

    echo json_encode($response);

    mysqli_close($conn);

?>