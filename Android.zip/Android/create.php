<?php

    define('host', 'localhost');
	define('user', 'root');
	define('pass', '');
	define('db', 'longdps13890_test');

	$conn = mysqli_connect(host, user, pass, db) or die('Unable to Connect');

    $title = $_POST['title'];
    $price = $_POST['price'];
    $rating = $_POST['rating'];
    $image = $_POST['image'];

    $sql = "INSERT INTO shop(title,price,rating,image) VALUES ('$title','$price','$rating','$image')";

    $result = mysqli_query($conn,$sql);

    if($result) 
    {
        echo"success";
    }
    else
    {
        echo"fail";
    }
    mysqli_close($conn);
?>
